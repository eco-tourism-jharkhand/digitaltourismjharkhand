import React, { useState } from 'react';
import { Music, Palette as Palette2, Calendar, Users } from 'lucide-react';

const Culture: React.FC = () => {
  const [selectedGalleryImage, setSelectedGalleryImage] = useState<string | null>(null);

  const culturalActivities = [
    {
      title: 'Tribal Dances',
      icon: Users,
      description: 'Traditional dances like Karma, Jadur, and Santhal dances that tell stories of harvest, nature worship, and community celebrations.',
      highlights: ['Karma Dance', 'Jadur Dance', 'Santhal Dance', 'Chhau Dance']
    },
    {
      title: 'Traditional Music',
      icon: Music,
      description: 'Folk music with indigenous instruments like Mandar, Dhol, and Flute, creating rhythms that connect communities with nature.',
      highlights: ['Mandar Beats', 'Dhol Rhythms', 'Flute Melodies', 'Folk Songs']
    },
    {
      title: 'Handicrafts',
      icon: Palette2,
      description: 'Exquisite handwoven textiles, bamboo crafts, and tribal pottery that showcase centuries-old artistic traditions.',
      highlights: ['Bamboo Crafts', 'Tribal Pottery', 'Handloom Textiles', 'Metal Crafts']
    }
  ];

  const festivals = [
    { name: 'Karma Festival', month: 'August', description: 'Worship of nature and trees' },
    { name: 'Sohrai Festival', month: 'November', description: 'Harvest celebration with cattle worship' },
    { name: 'Tusu Parab', month: 'January', description: 'Winter harvest festival' },
    { name: 'Sarhul Festival', month: 'March', description: 'Spring festival celebrating new leaves' },
    { name: 'Karam Festival', month: 'September', description: 'Youth festival with dancing and singing' },
    { name: 'Jatra Festival', month: 'October', description: 'Religious procession and cultural programs' }
  ];

  const galleryImages = [
    'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/3894157/pexels-photo-3894157.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/1619317/pexels-photo-1619317.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/7283149/pexels-photo-7283149.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/2850287/pexels-photo-2850287.jpeg?auto=compress&cs=tinysrgb&w=600',
    'https://images.pexels.com/photos/3894141/pexels-photo-3894141.jpeg?auto=compress&cs=tinysrgb&w=600'
  ];

  return (
    <div className="py-8">
      {/* Header Section */}
      <section className="bg-gradient-to-r from-amber-700 to-orange-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Cultural Heritage
          </h1>
          <p className="text-xl text-amber-100 max-w-2xl mx-auto">
            Immerse yourself in the rich tribal traditions and cultural heritage of Jharkhand
          </p>
        </div>
      </section>

      {/* Cultural Activities Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Rich Cultural Traditions
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {culturalActivities.map((activity, index) => (
              <div key={index} className="bg-gradient-to-br from-gray-50 to-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
                <div className="w-16 h-16 bg-amber-600 rounded-full flex items-center justify-center mb-6">
                  <activity.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">
                  {activity.title}
                </h3>
                <p className="text-gray-700 mb-6 leading-relaxed">
                  {activity.description}
                </p>
                <div className="space-y-2">
                  {activity.highlights.map((highlight, idx) => (
                    <div key={idx} className="flex items-center text-amber-700">
                      <div className="w-2 h-2 bg-amber-600 rounded-full mr-3"></div>
                      <span className="font-medium">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Festivals Calendar */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Calendar className="h-12 w-12 text-amber-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Festival Calendar
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Experience the vibrant festivals that celebrate the connection between tribal communities and nature
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {festivals.map((festival, index) => (
              <div key={index} className="bg-white rounded-lg p-6 shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-amber-500">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-bold text-gray-900">
                    {festival.name}
                  </h3>
                  <span className="bg-amber-100 text-amber-800 px-3 py-1 rounded-full text-sm font-semibold">
                    {festival.month}
                  </span>
                </div>
                <p className="text-gray-700">
                  {festival.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Image Gallery */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Cultural Gallery
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleryImages.map((image, index) => (
              <div
                key={index}
                className="group relative overflow-hidden rounded-xl cursor-pointer"
                onClick={() => setSelectedGalleryImage(image)}
              >
                <img
                  src={image}
                  alt={`Cultural activity ${index + 1}`}
                  className="w-full h-64 object-cover transition-transform duration-300 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-300 flex items-center justify-center">
                  <div className="text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="text-lg font-semibold">View Full Size</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Image Modal */}
      {selectedGalleryImage && (
        <div
          className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4"
          onClick={() => setSelectedGalleryImage(null)}
        >
          <div className="relative max-w-4xl max-h-full">
            <img
              src={selectedGalleryImage}
              alt="Gallery view"
              className="max-w-full max-h-full object-contain"
            />
            <button
              onClick={() => setSelectedGalleryImage(null)}
              className="absolute top-4 right-4 text-white bg-black bg-opacity-50 rounded-full w-10 h-10 flex items-center justify-center hover:bg-opacity-75 transition-colors"
            >
              ×
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Culture;