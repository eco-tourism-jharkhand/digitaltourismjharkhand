import React from 'react';
import { TreePine, Palette, Calendar, ArrowRight, MapPin, Camera, Mountain, BookTemplate as Temple } from 'lucide-react';

const Home: React.FC = () => {
  const highlights = [
    {
      icon: TreePine,
      emoji: '🌿',
      title: 'Eco Tourism',
      description: 'Explore pristine forests, waterfalls, and wildlife sanctuaries. Experience sustainable tourism that preserves nature for future generations.',
      features: ['Netarhat Hill Station', 'Betla National Park', 'Dassam Falls', 'Hundru Falls']
    },
    {
      icon: Palette,
      emoji: '🏛️',
      title: 'Cultural Heritage',
      description: 'Discover rich tribal traditions, ancient handicrafts, and indigenous art forms that have been preserved for centuries.',
      features: ['Tribal Dances & Music', 'Traditional Handicrafts', 'Ancient Temples', 'Local Cuisine']
    },
    {
      icon: Calendar,
      emoji: '🎉',
      title: 'Festivals',
      description: 'Experience colorful tribal festivals throughout the year, celebrating harvest seasons, nature worship, and community traditions.',
      features: ['Karma Festival', 'Sohrai Festival', 'Tusu Parab', 'Sarhul Festival']
    }
  ];

  const featuredDestinations = [
    {
      id: 1,
      name: 'Netarhat Hill Station',
      image: 'https://images.pexels.com/photos/1761279/pexels-photo-1761279.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Known as the "Queen of Chotanagpur", offering breathtaking sunrise and sunset views from 3,700 feet above sea level.',
      icon: Mountain,
      highlights: ['Sunrise Point', 'Magnolia Point', 'Pine Forest Walks']
    },
    {
      id: 2,
      name: 'Hundru Falls',
      image: 'https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'Spectacular 320-foot waterfall cascade creating a mesmerizing natural wonder perfect for photography and nature lovers.',
      icon: Camera,
      highlights: ['Photography Spots', 'Natural Pools', 'Trekking Trails']
    },
    {
      id: 3,
      name: 'Betla National Park',
      image: 'https://images.pexels.com/photos/33045/lion-wild-africa-african.jpg?auto=compress&cs=tinysrgb&w=800',
      description: 'Home to tigers, elephants, and diverse wildlife in pristine forest settings. Perfect for wildlife enthusiasts and eco-tourists.',
      icon: TreePine,
      highlights: ['Tiger Safari', 'Elephant Spotting', 'Bird Watching']
    },
    {
      id: 4,
      name: 'Baidyanath Dham',
      image: 'https://images.pexels.com/photos/7283149/pexels-photo-7283149.jpeg?auto=compress&cs=tinysrgb&w=800',
      description: 'One of the twelve Jyotirlingas, this sacred temple attracts millions of devotees and showcases ancient architectural brilliance.',
      icon: Temple,
      highlights: ['Sacred Jyotirlinga', 'Ancient Architecture', 'Spiritual Experience']
    }
  ];

  return (
    <div className="overflow-hidden">
      {/* Enhanced Hero Section */}
      <section 
        className="relative min-h-screen bg-cover bg-center bg-no-repeat flex items-center"
        style={{
          backgroundImage: 'linear-gradient(135deg, rgba(0,0,0,0.6), rgba(16,185,129,0.3)), url(https://images.pexels.com/photos/417173/pexels-photo-417173.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop)'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-transparent to-black/60"></div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl sm:text-6xl lg:text-7xl font-bold text-white mb-6 leading-tight">
              Discover Eco & Cultural
              <span className="block text-emerald-400">Wonders of Jharkhand</span>
            </h1>
            <p className="text-xl sm:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto leading-relaxed">
              Experience pristine forests, vibrant tribal culture, and sustainable tourism 
              in the heart of India's mineral-rich state where nature meets heritage.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <button className="group bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-2xl flex items-center gap-3">
                <span>Explore Now</span>
                <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              </button>
              <button className="group border-2 border-white text-white hover:bg-white hover:text-emerald-900 px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
                Watch Video
              </button>
            </div>
          </div>
        </div>
        
        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
          </div>
        </div>
      </section>

      {/* Enhanced Quick Highlights Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
              Why Choose Jharkhand?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Immerse yourself in nature's bounty while experiencing rich tribal heritage and sustainable tourism practices
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {highlights.map((highlight, index) => (
              <div key={index} className="group relative bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-3 hover:scale-105 border border-gray-100 overflow-hidden">
                {/* Background Pattern */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-emerald-50 to-transparent rounded-full transform translate-x-16 -translate-y-16 group-hover:scale-150 transition-transform duration-500"></div>
                
                <div className="relative z-10">
                  <div className="flex items-center mb-6">
                    <div className="w-16 h-16 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl flex items-center justify-center mr-4 group-hover:rotate-12 transition-transform duration-300 shadow-lg">
                      <highlight.icon className="h-8 w-8 text-white" />
                    </div>
                    <div className="text-4xl">{highlight.emoji}</div>
                  </div>
                  
                  <h3 className="text-2xl font-bold text-gray-900 mb-4 group-hover:text-emerald-700 transition-colors duration-300">
                    {highlight.title}
                  </h3>
                  
                  <p className="text-gray-700 mb-6 leading-relaxed">
                    {highlight.description}
                  </p>
                  
                  <div className="space-y-2">
                    {highlight.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center text-gray-600 group-hover:text-emerald-600 transition-colors duration-300">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full mr-3 group-hover:scale-125 transition-transform duration-300"></div>
                        <span className="font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Destinations Section */}
      <section className="py-20 bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl lg:text-5xl font-bold text-white mb-6">
              Featured Destinations
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Discover the most breathtaking locations that showcase Jharkhand's natural beauty and cultural richness
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {featuredDestinations.map((destination) => (
              <div key={destination.id} className="group relative bg-white rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2 hover:scale-105">
                <div className="relative overflow-hidden">
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-emerald-500 group-hover:text-white transition-all duration-300">
                    <destination.icon className="h-5 w-5" />
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-emerald-700 transition-colors duration-300">
                    {destination.name}
                  </h3>
                  
                  <p className="text-gray-600 mb-4 text-sm leading-relaxed">
                    {destination.description}
                  </p>
                  
                  <div className="space-y-1 mb-4">
                    {destination.highlights.map((highlight, idx) => (
                      <div key={idx} className="flex items-center text-xs text-gray-500">
                        <MapPin className="h-3 w-3 mr-2 text-emerald-500" />
                        <span>{highlight}</span>
                      </div>
                    ))}
                  </div>
                  
                  <button className="w-full bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-all duration-300 flex items-center justify-center gap-2 group-hover:shadow-lg">
                    Learn More
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Eco Tips Banner */}
      <section className="py-12 bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
            <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center">
                  <span className="text-3xl">🌱</span>
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-white mb-2">Travel Green</h3>
                  <p className="text-emerald-100 text-lg">
                    Carry reusable bottles, respect local culture, and keep Jharkhand clean
                  </p>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4 text-sm">
                <div className="bg-white/20 px-4 py-2 rounded-full text-white font-medium">
                  ♻️ Zero Waste
                </div>
                <div className="bg-white/20 px-4 py-2 rounded-full text-white font-medium">
                  🚶‍♂️ Walk More
                </div>
                <div className="bg-white/20 px-4 py-2 rounded-full text-white font-medium">
                  🌿 Respect Nature
                </div>
                <div className="bg-white/20 px-4 py-2 rounded-full text-white font-medium">
                  🤝 Support Locals
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl lg:text-5xl font-bold text-gray-900 mb-6">
            Ready to Explore Jharkhand?
          </h2>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed">
            Plan your eco-friendly adventure and immerse yourself in the cultural richness of Jharkhand. 
            Create memories that last a lifetime while contributing to sustainable tourism.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-emerald-600 hover:bg-emerald-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105 hover:shadow-xl">
              Plan Your Visit
            </button>
            <button className="border-2 border-emerald-600 text-emerald-600 hover:bg-emerald-600 hover:text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
              Download Guide
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;