import React from 'react';
import { Clock, MapPin, Leaf, Star, CheckCircle } from 'lucide-react';

const PlanVisit: React.FC = () => {
  const itineraries = [
    {
      title: 'Weekend Trip',
      duration: '2 Days / 1 Night',
      price: '₹3,500 per person',
      highlights: ['Hundru Falls', 'Rock Garden', 'Jagannath Temple', 'Local Markets'],
      itinerary: [
        { day: 'Day 1', activities: ['Arrival in Ranchi', 'Visit Hundru Falls', 'Evening at Rock Garden'] },
        { day: 'Day 2', activities: ['Jagannath Temple visit', 'Local market shopping', 'Departure'] }
      ]
    },
    {
      title: '5-Day Eco Tour',
      duration: '5 Days / 4 Nights',
      price: '₹12,000 per person',
      highlights: ['Netarhat Hill Station', 'Betla National Park', 'Dassam Falls', 'Village Homestay'],
      itinerary: [
        { day: 'Day 1', activities: ['Arrival in Ranchi', 'Drive to Netarhat', 'Sunset Point'] },
        { day: 'Day 2', activities: ['Sunrise viewing', 'Nature walks', 'Magnolia Point'] },
        { day: 'Day 3', activities: ['Travel to Betla', 'Wildlife safari', 'Tribal village visit'] },
        { day: 'Day 4', activities: ['Dassam Falls excursion', 'Eco-trekking', 'Cultural evening'] },
        { day: 'Day 5', activities: ['Return to Ranchi', 'Shopping', 'Departure'] }
      ]
    },
    {
      title: 'Adventure Tour',
      duration: '7 Days / 6 Nights',
      price: '₹18,500 per person',
      highlights: ['Trekking', 'Rock Climbing', 'River Rafting', 'Camping', 'Wildlife Photography'],
      itinerary: [
        { day: 'Day 1', activities: ['Arrival', 'Equipment briefing', 'Base camp setup'] },
        { day: 'Day 2', activities: ['Trekking in Netarhat hills', 'Camping under stars'] },
        { day: 'Day 3', activities: ['Rock climbing', 'Rappelling', 'Nature photography'] },
        { day: 'Day 4', activities: ['River rafting', 'Water sports', 'Riverside camping'] },
        { day: 'Day 5', activities: ['Wildlife safari', 'Bird watching', 'Tribal interaction'] },
        { day: 'Day 6', activities: ['Paragliding', 'Local cuisine tasting', 'Cultural show'] },
        { day: 'Day 7', activities: ['Departure', 'Memories to cherish'] }
      ]
    }
  ];

  const ecoTips = [
    {
      icon: Leaf,
      title: 'Reduce Plastic Usage',
      description: 'Carry reusable water bottles and avoid single-use plastics to keep our forests clean.'
    },
    {
      icon: CheckCircle,
      title: 'Respect Wildlife',
      description: 'Maintain safe distances from animals and avoid feeding them. Follow park guidelines strictly.'
    },
    {
      icon: MapPin,
      title: 'Stay on Designated Paths',
      description: 'Stick to marked trails to prevent soil erosion and protect native vegetation.'
    },
    {
      icon: Star,
      title: 'Support Local Communities',
      description: 'Buy local handicrafts, eat at local restaurants, and stay in community-run accommodations.'
    },
    {
      icon: Clock,
      title: 'Travel Responsibly',
      description: 'Use public transport or shared vehicles when possible. Consider carbon offsets for flights.'
    },
    {
      icon: Leaf,
      title: 'Leave No Trace',
      description: 'Pack out all trash, minimize campfire impact, and leave natural areas as you found them.'
    }
  ];

  return (
    <div className="py-8">
      {/* Header Section */}
      <section className="bg-gradient-to-r from-emerald-700 to-green-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Plan Your Visit
          </h1>
          <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
            Choose from our carefully curated itineraries for an unforgettable eco-cultural experience
          </p>
        </div>
      </section>

      {/* Sample Itineraries */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Sample Itineraries
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {itineraries.map((itinerary, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="bg-gradient-to-r from-emerald-600 to-green-500 p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">{itinerary.title}</h3>
                  <div className="flex items-center gap-4 text-emerald-100">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{itinerary.duration}</span>
                    </div>
                    <div className="text-xl font-semibold">
                      {itinerary.price}
                    </div>
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-900 mb-3">Highlights:</h4>
                    <div className="grid grid-cols-2 gap-2">
                      {itinerary.highlights.map((highlight, idx) => (
                        <div key={idx} className="flex items-center text-sm text-gray-700">
                          <CheckCircle className="h-4 w-4 text-emerald-500 mr-2 flex-shrink-0" />
                          <span>{highlight}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="space-y-4">
                    <h4 className="font-semibold text-gray-900">Itinerary:</h4>
                    {itinerary.itinerary.map((day, idx) => (
                      <div key={idx} className="border-l-2 border-emerald-200 pl-4">
                        <h5 className="font-semibold text-emerald-700 mb-1">{day.day}</h5>
                        <ul className="text-sm text-gray-600 space-y-1">
                          {day.activities.map((activity, actIdx) => (
                            <li key={actIdx} className="flex items-start">
                              <span className="mr-2">•</span>
                              <span>{activity}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                  
                  <button className="w-full mt-6 bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors duration-300">
                    Book This Tour
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Eco-Friendly Travel Tips */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Leaf className="h-12 w-12 text-emerald-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Eco-Friendly Travel Tips
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Help us preserve Jharkhand's natural beauty for future generations by following these sustainable travel practices
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {ecoTips.map((tip, index) => (
              <div key={index} className="bg-emerald-50 rounded-xl p-6 hover:shadow-lg transition-all duration-300 border border-emerald-100">
                <div className="w-12 h-12 bg-emerald-600 rounded-full flex items-center justify-center mb-4">
                  <tip.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {tip.title}
                </h3>
                <p className="text-gray-700 leading-relaxed">
                  {tip.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-emerald-900">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-white mb-6">
            Ready to Start Your Journey?
          </h2>
          <p className="text-xl text-emerald-100 mb-8">
            Contact our travel experts to customize your perfect Jharkhand experience
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-emerald-900 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-100 transition-colors duration-300">
              Contact Travel Expert
            </button>
            <button className="border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-emerald-900 transition-all duration-300">
              Download Brochure
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PlanVisit;