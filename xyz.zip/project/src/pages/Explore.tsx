import React, { useState } from 'react';
import { MapPin, Clock, Star, ArrowRight } from 'lucide-react';

const Explore: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const touristSpots = [
    {
      id: 1,
      name: 'Netarhat Hill Station',
      category: 'eco-tourism',
      image: 'https://images.pexels.com/photos/1761279/pexels-photo-1761279.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Known as the "Queen of Chotanagpur", offering breathtaking sunrise and sunset views.',
      duration: '2-3 days',
      rating: 4.5,
      location: 'Latehar District'
    },
    {
      id: 2,
      name: 'Betla National Park',
      category: 'eco-tourism',
      image: 'https://images.pexels.com/photos/33045/lion-wild-africa-african.jpg?auto=compress&cs=tinysrgb&w=600',
      description: 'Home to tigers, elephants, and diverse wildlife in pristine forest settings.',
      duration: '1-2 days',
      rating: 4.3,
      location: 'Latehar District'
    },
    {
      id: 3,
      name: 'Jagannath Temple, Ranchi',
      category: 'heritage',
      image: 'https://images.pexels.com/photos/7283149/pexels-photo-7283149.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Ancient temple dedicated to Lord Jagannath with beautiful architecture.',
      duration: 'Half day',
      rating: 4.2,
      location: 'Ranchi'
    },
    {
      id: 4,
      name: 'Hundru Falls',
      category: 'eco-tourism',
      image: 'https://images.pexels.com/photos/547115/pexels-photo-547115.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: '320-foot waterfall cascade creating a spectacular natural wonder.',
      duration: 'Half day',
      rating: 4.6,
      location: 'Ranchi District'
    },
    {
      id: 5,
      name: 'Tribal Museum',
      category: 'heritage',
      image: 'https://images.pexels.com/photos/1619317/pexels-photo-1619317.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Showcasing rich tribal heritage, art, and cultural artifacts.',
      duration: '2-3 hours',
      rating: 4.1,
      location: 'Ranchi'
    },
    {
      id: 6,
      name: 'Sohrai Festival Celebration',
      category: 'festivals',
      image: 'https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=600',
      description: 'Traditional harvest festival with vibrant tribal dances and rituals.',
      duration: '3-4 days',
      rating: 4.8,
      location: 'Various Villages'
    }
  ];

  const categories = [
    { id: 'all', label: 'All Places' },
    { id: 'eco-tourism', label: 'Eco Tourism' },
    { id: 'heritage', label: 'Heritage & Culture' },
    { id: 'festivals', label: 'Festivals' }
  ];

  const filteredSpots = activeCategory === 'all' 
    ? touristSpots 
    : touristSpots.filter(spot => spot.category === activeCategory);

  return (
    <div className="py-8">
      {/* Header Section */}
      <section className="bg-gradient-to-r from-emerald-700 to-green-600 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Explore Jharkhand
          </h1>
          <p className="text-xl text-emerald-100 max-w-2xl mx-auto">
            Discover amazing destinations that blend natural beauty with cultural richness
          </p>
        </div>
      </section>

      {/* Category Filter */}
      <section className="py-8 bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-emerald-600 text-white shadow-lg'
                    : 'bg-gray-100 text-gray-700 hover:bg-emerald-50 hover:text-emerald-600'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Tourist Spots Grid */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredSpots.map((spot) => (
              <div key={spot.id} className="group bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
                <div className="relative overflow-hidden">
                  <img
                    src={spot.image}
                    alt={spot.name}
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-emerald-600 text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {spot.category.replace('-', ' ').toUpperCase()}
                    </span>
                  </div>
                </div>
                
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {spot.name}
                  </h3>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      <span>{spot.location}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      <span>{spot.duration}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-1 mb-3">
                    <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm font-semibold">{spot.rating}</span>
                  </div>
                  
                  <p className="text-gray-700 mb-4 leading-relaxed">
                    {spot.description}
                  </p>
                  
                  <button className="w-full bg-emerald-600 text-white py-3 rounded-lg font-semibold hover:bg-emerald-700 transition-colors duration-300 flex items-center justify-center gap-2">
                    Learn More <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Google Map Section */}
      <section className="py-12 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-8">
            Jharkhand Tourist Locations
          </h2>
          <div className="rounded-xl overflow-hidden shadow-lg">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d931432.4841069632!2d84.85563955!3d23.347306349999998!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f4e104aa5db7dd%3A0xdc09d49d6899f43e!2sJharkhand!5e0!3m2!1sen!2sin!4v1641825555555!5m2!1sen!2sin"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Jharkhand Tourist Locations"
            ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Explore;