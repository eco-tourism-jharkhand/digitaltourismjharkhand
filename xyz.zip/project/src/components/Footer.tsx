import React from 'react';
import { Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-emerald-900 text-white py-8 mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4">Jharkhand Tourism</h3>
            <p className="text-emerald-100">
              Discover the eco and cultural wonders of Jharkhand. Experience nature, 
              heritage, and adventure in one of India's most beautiful states.
            </p>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-emerald-100">
              <li><a href="#" className="hover:text-white transition-colors">Tourist Spots</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Cultural Heritage</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Eco Tourism</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Travel Tips</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-lg font-semibold mb-4">Contact Info</h4>
            <ul className="space-y-2 text-emerald-100">
              <li>Tourist Helpline: 1800-XXX-XXXX</li>
              <li>Email: info@jharkhnadtourism.gov.in</li>
              <li>Emergency: 100 (Police), 102 (Ambulance)</li>
            </ul>
          </div>
        </div>
        <div className="border-t border-emerald-800 mt-8 pt-6 text-center">
          <p className="text-emerald-100 flex items-center justify-center gap-2">
            Made with <Heart className="h-4 w-4 text-red-400" /> for Hackathon 2025
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;